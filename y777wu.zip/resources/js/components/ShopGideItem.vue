<template>

    <div class="inner-box">
        <div class="image">
            <clazy-load class="wrapper" :src=" product.image">
                <transition name="fade">
                    <div class="divClass"
                         v-bind:style="{ backgroundImage: 'url('+ product.image + ')' }">
                    </div>
                </transition>
                <transition name="fade" slot="placeholder">
                    <div class="vue_preloader">
                        <div class="circle">
                            <div class="circle-inner"></div>
                        </div>
                    </div>
                </transition>
            </clazy-load>

        </div>
        <div class="clearfix ">
            <div class="pull-left" style="padding-left: 2em">
                <like-button class="like_product_button" type="product" :key="product.id" count-likes="0"
                             has-count="0"
                             :liked_id="product.id" :is_liked="product.is_like"></like-button>
            </div>
        </div>

        <div class="lower-content">
            <div class="product_name_and_price">
                <h6>
                    <router-link @click.native="$scrollToTop"
                                 :to="{ name: 'product_details', params: { id: product.id}}">
                        {{product.name}}
                    </router-link>
                </h6>
                <h6>
                    {{product.price}} ر.ي
                </h6>
            </div>

            <div class="detail_product_item">
                <rating-stars system="5"
                              :rating="4">
                    <span slot="after">({{product.average_rating}}) </span>
                </rating-stars>
                <p>
                    <i class="fa fa-map-marker "></i>
                    {{product.zone}}/   {{product.space}}/
                </p>


            </div>
            <!--            <div class="clearfix row add_to_cart_box">-->
            <!--                <div class="col-2 cart_icon" style=""-->
            <!--                ><i class="fa fa-cart-plus"></i></div>-->
            <!--                <div class="col-8"> إضافة الى السلة</div>-->
            <!--            </div>-->
        </div>
    </div>


</template>

<script>
    import LikeButton from './LikeButton.vue';
    import axios from "axios";
    import RatingStars from "./RatingStars";

    export default {
        props: ['product'],
        components: {LikeButton, RatingStars},

    }
</script>
