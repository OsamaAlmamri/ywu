<template>
    <div class="absolute inset-0 bg-gray-200 flex items-center justify-center">
       <div class="text-3xl text-center text-gray-700">Page Not Found! <br>404 ERROR!</div>
    </div>
</template>
<script>
export default {
    
}
</script>