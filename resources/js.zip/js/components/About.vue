<template>
    <div class="text-2xl text-green-800">
        About page
    </div>
</template>
<script>
export default {
    
}
</script>