<template>
    <section class="intro-section">
        <loading :active.sync="isLoading"
                 :can-cancel=false
                 :color="'#593c97'"
                 :loader="'dots'"
                 :background-color="'#f8f9fa'"
                 :height='200'
                 :width='140'
                 :on-cancel="onCancel()"
                 :is-full-page="fullPage">
        </loading>

        <sweet-modal
            :title="contentDeatail.name"
            :blocking=true
            width="70%"
            height="90%"
            :enable-mobile-fullscreen=true
            :pulse-on-block=true
            :overlay-theme="'dark'" ref="modal">
            <div v-html="contentDeatail.body"></div>

            <div name="buttons" slot="button">
                <button class="btn btn-info" @click.prevent="completeContent()">{{ $t('done') }}</button>
                <div class="pull-left">
                    <button class="btn btn-info" v-show="hav_prev" @click.prevent="prev()"> {{ $t('prev') }}</button>
                    <button class="btn btn-info" v-show="hav_next" @click.prevent="next()">{{ $t('next') }}</button>

                </div>
            </div>


        </sweet-modal>
        <div class="patern-layer-one paroller" data-paroller-factor="0.40" data-paroller-factor-lg="0.20"
             data-paroller-type="foreground" data-paroller-direction="vertical"
             style="background-image: url('site/images/icons/icon-1.png')"></div>
        <div class="patern-layer-two paroller" data-paroller-factor="0.40" data-paroller-factor-lg="-0.20"
             data-paroller-type="foreground" data-paroller-direction="vertical"
             style="background-image: url('site/images/icons/icon-2.png')"></div>
        <div class="circle-one"></div>
        <div class="auto-container">
            <div class="sec-title">
                <h2 class="d-flex flex-column justify-content-start">{{ training.name }}</h2>
            </div>

            <div class="inner-container">
                <div class="row clearfix">

                    <!-- Content Column -->
                    <div class="content-column col-lg-8 col-md-12 col-sm-12">
                        <div class="inner-column">

                            <!-- Intro Info Tabs-->
                            <div class="intro-info-tabs">
                                <!-- Intro Tabs-->
                                <div class="intro-tabs tabs-box">

                                    <!--Tab Btns-->
                                    <ul class="tab-btns tab-buttons clearfix">
                                        <li data-tab="#prod-overview" @click="changeActive('prod-overview')"
                                            :class="['tab-btn', {'active-btn':(activeTap=='prod-overview')}]">
                                            {{ $t('training.overview') }}


                                        </li>
                                        <li data-tab="#prod-curriculum" @click="changeActive('prod-curriculum')"
                                            :class="['tab-btn', {'active-btn':(activeTap=='prod-curriculum')}]">
                                            {{ $t('training.titles') }}

                                        </li>
                                        <li data-tab="#prod-reviews" @click="changeActive('prod-reviews')"
                                            :class="['tab-btn', {'active-btn':(activeTap=='prod-reviews')}]">
                                            {{ $t('training.rate') }}


                                        </li>
                                        <li v-if="calculateProgress=='100' && training.result==null "
                                            data-tab="#mcq_tap"
                                            @click="changeActive('mcq_tap')" id="mcq_tap_open"
                                            :class="['tab-btn', {'active-btn':(activeTap=='mcq_tap')}]">
                                            {{ $t('training.mcq') }}

                                        </li>
                                        <li v-if="training.result!=null"
                                            @click="changeActive('result')"
                                            :class="['tab-btn', {'active-btn':(activeTap=='result')}]">
                                            {{ $t('training.result') }}


                                        </li>
                                    </ul>

                                    <!--Tabs Container-->
                                    <div class="tabs-content">

                                        <!--Tab / Active Tab-->
                                        <div :class="['tab', {'active-tab':(activeTap=='prod-overview')}]"
                                             id="prod-overview">
                                            <div class="content">

                                                <!-- Cource Overview -->
                                                <div class="course-overview">
                                                    <div class="inner-box">

                                                        <h3 class="d-flex flex-column justify-content-start">
                                                            {{ $t('training.description') }}</h3>
                                                        <div class="d-flex flex-column justify-content-start"
                                                             v-html="training.description"></div>
                                                        <h3 class="d-flex flex-column justify-content-start">
                                                            {{ $t('training.learn') }} </h3>
                                                        <div v-html="training.learn"
                                                             class="d-flex flex-column justify-content-start"></div>

                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                        <!-- Tab -->
                                        <div class="tab" :class="['tab', {'active-tab':(activeTap=='prod-curriculum')}]"
                                             id="prod-curriculum">
                                            <div class="content">

                                                <!-- Accordion Box -->
                                                <ul class="accordion-box">
                                                    <!-- Block -->
                                                    <li class="accordion block"
                                                        v-for="(title,title_key) in training.titles">
                                                        <div :key="title_key" @click="change_active_lession(title_key)"
                                                             :class="['acc-btn',{'active':title_key==active_lession}]">
                                                            <div class="icon-outer"><span
                                                                class="icon icon-plus flaticon-angle-arrow-down"></span>
                                                            </div>
                                                            <i class="fa fa-check" :key="title_key"
                                                               v-if="title.is_complete"></i>

                                                            {{ title.name }}
                                                        </div>

                                                        <div
                                                            :class="['acc-content',{'current':title_key==active_lession}]">
                                                            <h3 v-if="title.contents.length==0"
                                                                style="margin-right: 90px"> سيتم اضافة المحتوى


                                                                قريبا
                                                            </h3>
                                                            <div v-for="(content,content_key) in title.contents"
                                                                 class="content" style="height: auto;">
                                                                <div class="clearfix">
                                                                    <div class="pull-right">
                                                                        <!--                                                                        contentCompleted(content,content_key,title_key)-->
                                                                        <i class="fa fa-check" :key="content_key"
                                                                           v-if="content.is_complete"></i>
                                                                        <a href="void(0)"
                                                                           @click.prevent="showContent(content,content_key,title_key)"
                                                                           :data-content="content"
                                                                           class="showContent">
                                                                            {{ content.title }}
                                                                        </a>
                                                                    </div>
                                                                    <div class="pull-left">
                                                                        <a v-if="content.video_url"
                                                                           href="javascript:void(0)"
                                                                           class="lightbox-image play-icon">
                                                                            <span class="fa fa-play"
                                                                                  @click="play(content.video_url,'video')"></span>
                                                                        </a>

                                                                        <a v-if="content.sound" :href="content.sound"
                                                                           href="javascript:void(0)"
                                                                           class="lightbox-image play-icon">
                                                                            <!-- audio element -->
                                                                            <!--                                                                            <vue-plyr>-->
                                                                            <!--                                                                                <audio controls crossorigin playsinline>-->
                                                                            <!--                                                                                    <source-->
                                                                            <!--                                                                                        :src="'http://127.0.0.1:8000/'+content.sound"-->
                                                                            <!--                                                                                        type="audio/mp3"-->
                                                                            <!--                                                                                    />-->
                                                                            <!--&lt;!&ndash;                                                                                    <source&ndash;&gt;-->
                                                                            <!--&lt;!&ndash;                                                                                        src="/path/to/audio.ogg"&ndash;&gt;-->
                                                                            <!--&lt;!&ndash;                                                                                        type="audio/ogg"&ndash;&gt;-->
                                                                            <!--&lt;!&ndash;                                                                                    />&ndash;&gt;-->
                                                                            <!--                                                                                </audio>-->
                                                                            <!--                                                                            </vue-plyr>-->
                                                                            <span class="fa fa-file-sound-o"
                                                                                  @click="play(content.sound,'audio')"></span>
                                                                        </a>
                                                                        <a v-if="content.book" :href="content.book"
                                                                           class="lightbox-image play-icon">
                                                                            <span class="fa fa-file-pdf-o"></span>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </div>


                                                        </div>

                                                    </li>

                                                </ul>

                                            </div>
                                        </div>

                                        <!-- Tab -->
                                        <div :class="['tab', {'active-tab':(activeTap=='mcq_tap')}]" id="mcq_tap">
                                            <div class="content">
                                                <course-questions v-on:set_result="set_my_result"></course-questions>

                                            </div>
                                        </div>


                                        <!-- Tab -->
                                        <div :class="['tab', {'active-tab':(activeTap=='result')}]">
                                            <div class="content" v-if="training.result!=null">
                                                <h3> {{ $t('training.your_result') }}</h3>
                                                <h2>{{ training.result.grade }}</h2>

                                            </div>
                                        </div>


                                        <!-- Tab -->
                                        <div :class="['tab', {'active-tab':(activeTap=='prod-reviews')}]"
                                             id="prod-reviews">
                                            <div class="content">


                                                <div class="row" style="margin:0px 10px 30px;">
                                                    <div class=" col-md-4">
                                                        <div
                                                            class="udlite-heading-xxxl review-summary-widget--average-number--2Q0bz">
                                                            {{ training.rating_details.average }}
                                                        </div>
                                                        <p class="review-summary-widget--average-rating-text--2BT9O">
                                                            <rating-stars system="5"
                                                                          :rating="training.rating_details.average"></rating-stars>


                                                            {{ $t('rating.sum') }}
                                                            {{ training.rating_details.sum }}
                                                        </p>
                                                    </div>

                                                    <div class=" col-md-7 ">
                                                        <div class="row" v-for="i in reverseKeys(5)">
                                                            <div class="col-8">
                                                                <div class="row progress md-progress"
                                                                     style="height: 20px; margin-bottom: 10px; ">
                                                                    <div class="progress-bar progress-bar-success"
                                                                         role="progressbar"
                                                                         :style="[{'width': valueWidth(i+1)+'%'}, {'height': '20px'}]"
                                                                         :aria-valuenow="valueWidth(i+1)"
                                                                         aria-valuemin="0" aria-valuemax="100">
                                                                        {{ valueWidth(i + 1) }} %
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-4">
                                                                <rating-stars system="5" :rating="i+1"></rating-stars>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <hr>
                                                </div>

                                                <div class="row new_rating_dev " v-show="show_new_rateForm">
                                                    <fieldset class="the-fieldset new_rating_dev"
                                                              style="border: 1px solid #e0e0e0; padding: 10px;">
                                                        <legend class="the-legend">
                                                            {{ $t('rating.add') }}
                                                        </legend>
                                                        <rating-stars2 font_size='3' v-on:change="change_new_rating_val"
                                                                       :value="newRating.rating"></rating-stars2>
                                                        <div class="form-group" style="width: 100%">
                                                            <fieldset class="the-fieldset">
                                                                <legend class="the-legend">
                                                                    {{ $t('rating.message') }}

                                                                </legend>
                                                                <textarea style="width: 100%" rows="4" class=""
                                                                          v-model="newRating.message"></textarea>
                                                            </fieldset>
                                                        </div>
                                                        <button class="btn btn-primary" @click="rating()">

                                                            {{ $t('rating.save') }}
                                                        </button>
                                                        <button class="btn btn-warning" @click="edit_rate=false"
                                                                v-show="training.is_rating!=null">

                                                            {{ $t('cancel') }}
                                                        </button>
                                                    </fieldset>
                                                </div>

                                                <div v-if="showOldRating"
                                                     class="cource-review-box">
                                                    <div style="width: 100%; display: inline-block;">

                                                        <dropdown>
                                                            <div slot="items">
                                                                <a class="dropdown-item" href="#"
                                                                   @click.prevent="edit_rating()">{{ $t('edit') }}</a>
                                                                <a class="dropdown-item" href="#"
                                                                   @click.prevent="deleteRating()"> {{
                                                                        $t('delete')
                                                                    }} </a>
                                                            </div>
                                                        </dropdown>

                                                        <h4 class="pull-right">
                                                            {{ training.is_rating.user_rater.name }} </h4>
                                                    </div>
                                                    <div class="rating">
                                                        <rating-stars :rating="training.is_rating.rating" system="5">
                                                            <span
                                                                slot="after"> {{ training.is_rating.published }}</span>
                                                        </rating-stars>
                                                    </div>
                                                    <div class="text">{{ training.is_rating.message }}</div>
                                                    <hr>
                                                </div>


                                                <div v-for="rating in training.ratings" class="cource-review-box">
                                                    <h4>{{ rating.user_rater.name }} </h4>
                                                    <div class="rating">
                                                        <rating-stars :rating="rating.rating" system="5">
                                                            <span slot="after"> {{ rating.published }}</span>
                                                        </rating-stars>
                                                    </div>
                                                    <div class="text">{{ rating.message }}</div>
                                                    <hr>
                                                </div>


                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- Video Column -->
                    <div class="video-column col-lg-4 col-md-12 col-sm-12">
                        <div class="inner-column sticky-top" v-if="active_player_type!=''">
                            <vue-plyr ref="plyr" @player="setPlayer">
                                <audio v-if="active_player_type=='audio'" controls crossorigin playsinline>
                                    <source
                                        :src="active_player"
                                        :type="'audio/'+audio_type(active_player_type)"
                                    />
                                    <!--                                                                                    <source-->
                                    <!--                                                                                        src="/path/to/audio.ogg"-->
                                    <!--                                                                                        type="audio/ogg"-->
                                    <!--                                                                                    />-->
                                </audio>


                                <div v-else data-plyr-provider="youtube" :data-plyr-embed-id="youtube_id(active_player_type)"
                                    ></div>
                            </vue-plyr>
                        </div>
                        <div class="inner-column sticky-top">
                            <div class="">
                                <div class="thumbnail">
                                    <div class="thumb">
                                        <a v-bind:href="BaseImagePath + training.thumbnail"
                                           data-lightbox="1" data-title="">
                                            <img v-bind:src="BaseImagePath + training.thumbnail"
                                                 width="100%" alt="" class="img-fluid img-thumbnail">
                                        </a>
                                    </div>
                                </div>

                                <!--                            <clazy-load class="wrapper intro-video" :src="'assets/images/' + training.thumbnail">-->
                                <!--                                <transition name="fade">-->
                                <!--                                    <div class="intro-video"-->
                                <!--                                         v-bind:style="{ backgroundImage: 'url(assets/images/' + training.thumbnail + ')' }">-->
                                <!--                                    </div>-->
                                <!--                                </transition>-->
                                <!--                                <transition name="fade" slot="placeholder">-->
                                <!--                                    <div class="vue_preloader">-->
                                <!--                                        <div class="circle">-->
                                <!--                                            <div class="circle-inner"></div>-->
                                <!--                                        </div>-->
                                <!--                                    </div>-->
                                <!--                                </transition>-->
                                <!--                            </clazy-load>-->
                            </div>

                            <!-- End Video Box -->
                            <div class="price" style="font-size: 20px">{{ training.length }} <i
                                class="fa fa-clock-o"></i>
                            </div>
                            <div class="time-left" v-if="training.start_at!=null"><span style="font-weight: 700">
                                {{ $t('training.start_at') }}
                                </span>
                                {{ training.start_at }}
                            </div>
                            <div class="time-left" v-if="training.end_at!=null"><span style="font-weight: 700">
                                {{ $t('training.end_at') }}
                             </span><
                                {{ training.end_at }}
                            </div>

                            <button @click="likePost()"
                                    class="theme-btn btn-style-three"><span
                                class="txt">
                                 {{ (training.is_like == null ? $t('add_fav') : $t('cancel_fav')) }}
                                <i class="fa fa-angle-left"></i>

                            </span></button>
                            <div>
                                <h4 class="d-flex flex-column justify-content-start"> {{ $t('training.progress') }}</h4>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-success"
                                         role="progressbar"
                                         :style="[{'width': calculateProgress+'%'}, {'height': '20px'}]"
                                         :aria-valuenow="calculateProgress"
                                         aria-valuemin="0" aria-valuemax="100">{{ calculateProgress }}%
                                    </div>
                                </div>
                            </div>

                            <a href="#" v-show="showRegisterButton"
                               @click="registerInCourse()"
                               class="theme-btn btn-style-two"><span
                                class="txt"> {{ registerDecription }}   <i
                                class="fa fa-angle-left"></i></span></a>


                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>
</template>

<script>
import RatingStars from './RatingStars.vue';
import axios from "axios";
import Loading from 'vue-loading-overlay';
// Import stylesheet
import 'vue-loading-overlay/dist/vue-loading.css';
import RatingStars2 from "./RatingStars2";
import LikeButton from "./LikeButton";
import i18n from "./../plugins/vue-i18n";

export default {
    props: ['items'],
    // components: {question},
    components: {RatingStars2, Loading, RatingStars, LikeButton},

    data() {
        return {
            isLoading: false,
            edit_rate: false,
            fullPage: true,
            player: {},
            active_player: "",
            active_player_type: "",
            is_active_dropdown: false,
            training: {
                "id": 0,
                "category_id": 0,
                "name": "",
                "description": "",
                "learn": "",
                "instructor": null,
                "has_certificate": 0,
                "mark": 0,
                "type": " ",
                "length": " ",
                "start_at": " ",
                "end_at": " ",
                "thumbnail": " ",
                "deleted_at": null,
                "published": " ",
                "can_register": 1,
                "average_rating": 5,
                "count_rating": 1,
                "percent_rating": 100,
                "is_like": null,
                "user_complete": {
                    "is_complete": false,
                    "complete": 3,
                    "titles": 7
                },
                "ratings": [
                    {
                        "id": 2,
                        "rateable_type": "",
                        "rateable_id": 0,
                        "rating": 0,
                        "message": "",
                        "user_id": 0,
                        "created_at": "",
                        "updated_at": "",
                        "published": " ",
                        "user_rater": {
                            "id": 0,
                            "name": " ",
                            "type": "",
                            "published": ""
                        }
                    }
                ],
                "rating_details": {
                    "one": 0,
                    "tow": 0,
                    "three": 0,
                    "four": 0,
                    "five": 0,
                    "sum": 0,
                    "average": 0
                },
                "is_rating": null,
                "result": null,
                "is_register": {
                    "id": 0,
                    "user_id": 0,
                    "training_id": 0,
                    "status": 0,
                    "created_at": "",
                    "updated_at": "",
                    "published": ""
                },
                "titles": []
            },
            newRating:
                {
                    course_id: 0,
                    rating: 1,
                    message: '',
                },
            activeContent: {
                "id": 0,
                "is_complete": false,
                "title": "",
                "body": "",
                "image": "",
                "book": "",
                "sound": "",
                "video_url": "",
                "title_id": 0,
                "deleted_at": null,
                "published": "منذ أسبوع"
            },
            activeIndex: null,
            active_lession: 0,
            active_title_complete: 0,
            activeTap: 'prod-overview',
            sections: [],
            course_id: '',
            activeContent_key: 0,
            activeContent_title_key: 0,
            pagination: {},
            edit: false
        }
    },
    created() {
        this.course_id = this.$route.params.id
        this.newRating.course_id = this.$route.params.id
        this.fetchTraining();
    },
    computed: {
        contentDeatail() {
            return this.activeContent;
        },
        showRegisterButton() {
            return ((this.training.can_register == 1) && this.training.is_begin_training == false);
        },
        hav_prev() {
            return this.activeContent_key > 0;
        },
        hav_next() {
            return this.activeContent_key < (this.current_content_length - 1);
            // return this.activeContent;
        },
        current_content_length() {
            if (this.training.titles.length > 0)
                return this.training.titles[this.activeContent_title_key].contents.length;

            // return this.activeContent;
        },
        registerDecription() {
            if (this.training.is_register == null)

                return i18n.t('training.register');
            else if (this.training.is_begin_training == false)
                return i18n.t('training.begin_training');

                //     return ' الغاء التسجيل  ';
                // else
            //     return '    التسجيل  ';
            else
                return '      ';

        },
        calculateProgress() {
            let titles = this.training.user_complete.titles;
            let trainings = 0;

            for (var i = 0; i < this.training.titles.length; i++) {
                if (this.training.titles[i].is_complete) {
                    trainings++;
                }
            }
            var p = (trainings / ((titles > 0) ? titles : 1)) * 100;
            return (p.toFixed(0));
        },
        show_new_rateForm() {
            return (this.training.is_rating == null || this.edit_rate == true);
        },
        showOldRating() {
            // return false;
            return (this.training.is_rating != null && this.edit_rate == false);
        },

        contentCompleted(content, content_key, title_key) {
            return this.training.titles[title_key].contents[content_key].is_complete;

        },

    }
    ,
    methods: {
        valueWidth(i) {
            switch (i) {
                case 1:
                    return this.training.rating_details.one;
                    break;
                case 2:
                    return this.training.rating_details.tow;
                    break;
                case 3:
                    return this.training.rating_details.three;
                    break;
                case 4:
                    return this.training.rating_details.four;
                    break;
                case 5:
                    return this.training.rating_details.five;
                    break;

            }
            return this.tr;
        },
        likePost() {
            if (localStorage.token) {
                axios({
                    url: '/api/like', data: {type: 'trainings', liked_id: this.training.id},
                    method: 'POST'
                })
                    .then(resp => {
                        if (resp.data.status == false) {
                            toastStack('   خطاء ', resp.data.msg, 'error');
                        } else {
                            var like = resp.data.data;
                            if (like == 1)
                                this.training.is_like = {'training_id': '1'};
                            else
                                this.training.is_like = null;
                        }
                    })
                    .catch(err => {
                        console.log(err)
                    })
            } else {
                toastStack('   خطاء ', 'يجب تسجيل الدخول اولا', 'error');
            }
        },
        registerInCourse() {
            if (localStorage.token) {
                if (this.training.is_register != null && this.training.is_begin_training == false) {
                    this.training.is_begin_training = true;
                } else {
                    axios({
                        url: '/api/register_to_training', data: {
                            training_id: this.training.id
                        }, method: 'POST'
                    }).then(resp => {
                        if (resp.data.status == false) {
                            toastStack('   خطاء ', resp.data.msg, 'error');
                        } else {
                            this.training.is_register = resp.data.data;
                            toastStack(resp.data.msg, '', 'success');
                        }
                    }).catch(err => {
                        console.log(err)
                    })
                }
            } else {
                toastStack('   خطاء ', 'يجب تسجيل الدخول اولا', 'error');
            }
            this.$emit('click', this.$vnode.key)
        },
        change_new_rating_val: function (newVal) {
            this.newRating.rating = newVal;
        },
        next: function () {
            // if (this.hav_next() == true)
            this.activeContent = this.training.titles[this.activeContent_title_key].contents[this.activeContent_key + 1];
            this.activeContent_key += 1;

        },
        prev: function () {
            // this.newRating.rating = newVal;
            this.activeContent = this.training.titles[this.activeContent_title_key].contents[this.activeContent_key - 1];
            this.activeContent_key -= 1;
        },
        likeTraining: function (is_like) {
            if (is_like == 1)
                this.training.is_like = {'id': this.rating.id}
            else
                this.training.is_like = null;
        },

        onToggle(index) {
            if (this.activeIndex == index) {
                return (this.activeIndex = null);
            }
            this.activeIndex = index;
        }
        ,
        showContent(content, content_key, title_key) {
            if (this.is_begin_training == false)
                toastStack('   خطاء ', 'يرجى تحديد البدء بالدورة اولا', 'error');

            else {
                this.activeContent = content;
                this.activeContent_key = content_key;
                this.activeContent_title_key = title_key;
                this.$refs.modal.open();
            }
        }
        ,
        openModal() {
            this.$refs.modal.open();
        }
        ,
        changeActive(index) {
            this.activeTap = index;
        }
        ,
        change_active_lession(index) {
            this.active_lession = index;
        }
        ,
        reverseKeys(n) {
            return [...Array(n).keys()].slice().reverse()
        }
        ,
        edit_rating() {
            this.is_active_dropdown = false;
            this.edit_rate = true;
            this.newRating.rating = this.training.is_rating.rating;
            this.newRating.message = this.training.is_rating.message;

        },
        fetchTraining() {
            this.isLoading = true;
            axios({url: '/api/getTrainingDetails', data: {id: this.course_id}, method: 'POST'})
                .then(resp => {
                    this.isLoading = false;
                    if (resp.data.status == false) {
                        toastStack('   خطاء ', resp.data.msg, 'error');
                    } else {
                        this.training = resp.data.Trainings;
                    }
                })
                .catch(err => {
                    this.isLoading = false;
                    localStorage.removeItem('token')
                    localStorage.removeItem('user')
                    reject(err)
                })
            // fetch('/api/ShowTrainings2', {
            //     method: 'post',
            //     headers: {
            //         'Content-Type': 'application/json',
            //         // 'Authorization': 'Bearer my-token',
            //         // 'My-Custom-Header': 'foobar'
            //     },
            //     body: JSON.stringify({id: this.course_id, title: 'Vue POST Request Example'})
            // })
            //     .then(res => res.json())
            //     .then(res => {
            //         this.training = res.Trainings;
            //     })
            //     .catch(err => console.log(err));
        },

        completeContent() {
            axios({url: '/api/complete_content', data: {id: this.activeContent.id}, method: 'POST'})
                .then(resp => {
                    if (resp.data.status == false) {
                        toastStack('   خطاء ', resp.data.msg, 'error');
                    } else {
                        this.training.titles[this.activeContent_title_key].contents[this.activeContent_key].is_complete = true;
                        this.training.titles[this.activeContent_title_key].is_complete = resp.data.title_complete;
                        this.$refs.modal.close();
                        this.training.is_begin_training = true;
                    }
                    this.isLoading = false;
                })
                .catch(err => {
                    this.isLoading = false;
                    console.log(err)
                })
        },
        rating() {
            this.isLoading = true;
            axios({url: '/api/training/rate2', data: this.newRating, method: 'POST'})
                .then(resp => {
                    if (resp.data.status == false) {
                        toastStack('   خطاء ', resp.data.msg, 'error');
                    } else {
                        toastStack(resp.data.msg, '', 'success');
                        // this.training.is_rating = resp.data.data;
                        this.training.is_rating = resp.data.data.is_rating;
                        this.training.ratings = resp.data.data.ratings;
                        this.training.rating_details = resp.data.data.rating_details;
                        this.edit_rate = false;
                    }
                    this.isLoading = false;
                })
                .catch(err => {
                    this.isLoading = false;
                    console.log(err)
                })
        },
        deleteRating() {
            this.isLoading = true;
            axios({url: '/api/training/delete_rate2', data: {id: this.training.is_rating.id}, method: 'POST'})
                .then(resp => {
                    if (resp.data.status == false) {
                        toastStack('   خطاء ', resp.data.msg, 'error');
                    } else {
                        toastStack(resp.data.msg, '', 'success');
                        // if (resp.data.data == 1) {
                        this.training.is_rating = resp.data.data.is_rating;
                        this.training.ratings = resp.data.data.ratings;
                        this.training.rating_details = resp.data.data.rating_details;
                        // this.training.is_rating = null;
                        this.edit_rate = true;
                        // }


                    }
                    this.isLoading = false;
                })
                .catch(err => {
                    this.isLoading = false;
                    console.log(err)
                })
        },

        set_my_result(grade) {
            // this.isLoading = true;
            axios({
                url: '/api/set_result',
                data: {grade: grade, training_id: this.training.id},
                method: 'POST'
            })
                .then(resp => {
                    if (resp.data.status == false) {
                        toastStack('   خطاء ', resp.data.msg, 'error');
                    } else {
                        toastStack(resp.data.msg, '', 'success');
                        this.training.result = resp.data.data;
                        this.activeTap = 'result';

                    }
                    this.isLoading = false;
                })
                .catch(err => {
                    this.isLoading = false;
                    console.log(err)
                })
        },

        play(url, type) {
            this.active_player = 'http://127.0.0.1:8000/' + url
            this.active_player_type = type
            if (type == 'audio')
                this.$refs.plyr.player.source = {
                    type: 'audio',
                    title: 'Example title',
                    sources: [
                        {
                            src: 'https://yemenwe.com/' + url,
                            type: 'audio/'+this.audio_type(url),
                        },

                    ],
                };
            else
                this.$refs.plyr.player.source = {
                    type: 'video',
                    sources: [
                        {
                            src: this.youtube_id(url),
                            provider: 'youtube',
                        },
                    ],
                };
            this.$refs.plyr.player.play()
        },
        setPlayer(player) {
            this.$refs.plyr.player = player
        },
        audio_type(player) {
           return player.split('.').pop();

        },
        youtube_id(player) {
           return player.split('//').pop();

        },
        onCancel() {
            console.log('User cancelled the loader.')
        }

    }
    ,
    mounted() {
        console.log('Component mounted.')
    }
    ,


}
</script>

<style>
.dropdown_animation {
    position: absolute;
    transform: translate3d(0px, 38px, 0px);
    top: 0px;
    left: 0px;
    will-change: transform;
}
</style>
