<template>
    <a href="#">

        {{ $t('footer') }}
        @{{ new Date().getFullYear() }}
    </a>

</template>
