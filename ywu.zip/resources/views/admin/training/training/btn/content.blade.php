<a href="{{route('questions.results',$id)}}"  title="النتائج" class="btn btn-info btn-sm" style="float: right"> النتائج</a>
<a href="{{route('questions.index',$id)}}"  title="العناوين" class="btn btn-info btn-sm" style="float: right"> الاسئلة</a>
<a href="{{route('showTitles',$id)}}"  title="العناوين" class="btn btn-info btn-sm" style="float: right"> العناوين</a>
