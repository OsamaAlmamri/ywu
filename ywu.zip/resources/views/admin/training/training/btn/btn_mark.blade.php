<a data-id="{{$id}}"
   data-status="{{$mark}}" data-active_type="mark"
   class="active_disable_btn"  >
    @if($mark==1)
        <i class="fa fa-star" style="color: #f6de02; font-size: 20px"> </i>
    @else
        <i class="fa fa-star" style="color: black; font-size: 20px"> </i>

    @endif
</a>
