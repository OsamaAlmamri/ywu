@if($image!=null)
    <div class="thumbnail">
        <div class="thumb">
            <a href="{{($image)}}" data-lightbox="1" data-title="My caption 1">
                <img src="{{($image)}}" width="100" alt="" class="img-fluid img-thumbnail">
            </a>
        </div>
    </div>
@endif
