<button type="button" name="delete" id="{{$id}}" class="delete btn btn-danger btn-sm" style="float: right"><span
        class='glyphicon glyphicon-trash'> </span></button>
