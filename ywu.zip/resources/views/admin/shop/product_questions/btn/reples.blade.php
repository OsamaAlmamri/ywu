<a href="{{route('admin.shop.product_questions.show_replies',$id)}}" style=" margin-left: 10px;">
    {{$replaies}}
</a>
