<a class="btn btn-info btn-sm" href="{{route('admin.shop.orders.show_main_order',$order_id)}}"
   style=" margin-left: 10px;">
    عرض الطلب
</a>

