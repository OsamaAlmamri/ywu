<div class="manage_btns">
    <a class=" btn btn-primary btn-sm" href="mailto:{{$email}}"><i class="fa fa-mail-reply-all"></i></a>
    <a class=" btn btn-info btn-sm" href="tel:{{$phone}}"><i class="fa fa-phone"></i></a>
    <button type="button" name="delete" id="{{$id}}" class="delete btn btn-danger btn-sm" style="float: right"><span
            class='glyphicon glyphicon-trash'> </span></button>
</div>

