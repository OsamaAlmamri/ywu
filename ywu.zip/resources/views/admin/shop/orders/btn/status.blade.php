@if (auth()->user()->type=='admin')
    @if (isset($payment_status)and $payment_status==0)
        <button type="button" name="delete" id="{{$id}}" class="payment btn btn-info btn-sm"
                style="float: right"> تاكيد الدفع
        </button>
    @else
        تم الدفع
    @endif

@else
    <a class="btn btn-info btn-sm" href="{{route('admin.shop.orders.show_main_order',$id)}}"
       style=" margin-left: 10px;">
        عرض التفاصيل
    </a>
@endif
