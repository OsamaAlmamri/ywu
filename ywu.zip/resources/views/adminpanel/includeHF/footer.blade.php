<footer class="hidden-print">
    <div class="pull-left">
    </div>
    <div class="clearfix"></div>
</footer>
