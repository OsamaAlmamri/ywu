<?php

namespace App\Models\Shop;


use App\Admin;
use Illuminate\Database\Eloquent\Model;

class OrderSeller extends Model
{
    //
    public $timestamps = false;

    protected $fillable = ['order_id', 'seller_id', 'status', 'price', 'shipping_cost', 'shipping_method'];

    protected $appends = ['seller_name','seller', 'order_status_name'];

    function getOrderStatusNameAttribute()
    {
        $status = $this->attributes['status'];
        return trans('status.order_' . $status);
    }

    public function getSellerAttribute()
    {
        $s = $this->admin()->get()->first();
        $s->seller = $s->seller;
        return $s;

    }
    public function getSellerNameAttribute()
    {
        $s = $this->admin()->get()->first();
        return $s->seller->sale_name;

    }

    protected $with = ['products'];


    public function admin()
    {
        return $this->belongsTo(Admin::class, 'seller_id', 'id');
    }

    public function order()
    {
        return $this->belongsTo(Order::class, 'order_id', 'id');
    }

    public function products()
    {
        return $this->hasMany(OrderProduct::class, 'order_seller_id', 'id');
    }
}
