<?php

namespace App\Models\Shop;

use Illuminate\Database\Eloquent\Model;

class ImageCategory extends Model
{
    protected $table='image_categories';
    //
}
