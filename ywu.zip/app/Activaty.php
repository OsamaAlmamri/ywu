<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Activaty extends Model
{
    //
    protected $fillable = ['url', 'sort', 'description', 'title', 'status', 'image', 'type'];

}
