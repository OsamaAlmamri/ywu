<?php

return [
    "lang" => "عربي",
    "order_date" => "order date ",
    "information_date" => "information date",
    "bill_to" => "bill to",
    "ship_to" => "ship to",
    "order_number" => "order number",
    "main_order_number" => "main order number",
    "coupon" => "coupon",
    "address" => "Delivery Location",

    "coupon_discount" => " coupon discount",
    "phone_number" => "phone number",
    "order_cost" => " order cost",
    "after_discount" => "after discount ",
    "order_status" => "order status",
    "seller_name" => "seller name",
    "trade+name" => " trade name",
    "by_the_client" => "by the client",
    "payment_method" => "payment method",
    "payment_status" => "payment status",
    "quantity" => "quantity",
    "item" => "item",
    "product" => "product ",
    "product_options" => " product options  ",
    "real" => "YER",
    "unit_price" => "unit price ",
    "total" => "total",
    'on_delivery' => '',
    'transfer' => ''
];
