<a class="btn btn-info btn-sm" href="{{route('admin.shop.orders.show_seller_order',$id)}}"
   style=" margin-left: 10px;">
    عرض التفاصيل
</a>

