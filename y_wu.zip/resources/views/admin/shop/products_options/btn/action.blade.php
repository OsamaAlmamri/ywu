<button type="button" name="edit" id="{{$products_options_id}}"
        data-id="{{$products_options_id}}"
        data-option_name="{{$products_options_name}}"

        class="edit btn btn-warning btn-sm"
        style="float: right"><span
        class='glyphicon glyphicon-pencil'></span></button>
<button type="button" name="delete" id="{{$products_options_id}}"
        data-type="option"
        class="delete btn btn-danger btn-sm" style="float: right"><span
        class='glyphicon glyphicon-trash'> </span></button>
